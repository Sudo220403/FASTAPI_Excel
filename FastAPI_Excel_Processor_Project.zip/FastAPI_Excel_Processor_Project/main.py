
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import os

app = FastAPI(
    title="FastAPI Excel Processor",
    description="API for processing Excel sheets",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

EXCEL_FILE_PATH = os.path.join("data", "capbudg.xls")
sheet_cache = {}

def load_excel():
    try:
        xl = pd.read_excel(EXCEL_FILE_PATH, sheet_name=None, engine='xlrd')
        global sheet_cache
        sheet_cache = xl
        return xl
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read Excel file: {str(e)}")

@app.get("/list_tables", tags=["List Tables"])
def list_tables():
    if not sheet_cache:
        load_excel()
    return {"tables": list(sheet_cache.keys())}

@app.get("/get_table_details", tags=["Get Table Details"])
def get_table_details(table_name: str = Query(..., description="Name of the Excel sheet")):
    if not sheet_cache:
        load_excel()
    if table_name not in sheet_cache:
        raise HTTPException(status_code=404, detail="Table not found")
    df = sheet_cache[table_name]
    first_col = df.columns[0]
    row_names = df[first_col].dropna().astype(str).tolist()
    return {"table_name": table_name, "row_names": row_names}

@app.get("/row_sum", tags=["Row Sum"])
def row_sum(
    table_name: str = Query(..., description="Name of the Excel sheet"),
    row_name: str = Query(..., description="Name of the row to sum")
):
    if not sheet_cache:
        load_excel()
    if table_name not in sheet_cache:
        raise HTTPException(status_code=404, detail="Table not found")

    df = sheet_cache[table_name]
    first_col = df.columns[0]
    row = df[df[first_col].astype(str).str.strip() == row_name.strip()]

    if row.empty:
        raise HTTPException(status_code=404, detail="Row not found")

    numeric_sum = row.select_dtypes(include=['number']).sum(axis=1).iloc[0]
    return {
        "table_name": table_name,
        "row_name": row_name,
        "sum": numeric_sum
    }
