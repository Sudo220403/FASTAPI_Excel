
# FastAPI Excel Processor

## How to Run

1. Install dependencies:

```bash
pip install fastapi uvicorn pandas openpyxl xlrd
```

2. Run the API server:

```bash
uvicorn main:app --host 127.0.0.1 --port 9090
```

3. Open in browser:

```
http://127.0.0.1:9090/docs
```

## Endpoints

- `GET /list_tables`
- `GET /get_table_details?table_name=...`
- `GET /row_sum?table_name=...&row_name=...`
